from __future__ import division
import sys, os
import random
import copy 
import time
from ast import literal_eval

class Node:
	def __init__(self,p):
		self.coordinates = p
		self.pointList = []
		self.pointList.append(p)
		self.parent = None
		self.left = None
		self.right = None

class Point:
	def __init__(self,p):
		self.coordinates = []
		try:
			for x in range(0,len(p)):
				self.coordinates.append(p[x])
		except:
			self.coordinates.append(p)
		self.centroid = None
		
class Centroid:
	count = 0
	def __init__(self,point):
		self.point = point
		self.count = Centroid.count
		self.pointList = []
		self.addPoint(point)
		self.centerPos = []
		self.centerPos.append(self.point)
		self.clusterError = 0
		Centroid.count += 1;
		
	def update(self,point):
		self.point = point
		self.centerPos.append(self.point)
		
	def addPoint(self,point):
		self.pointList.append(point)
		
	def removePoint(self,point):
		self.pointList.remove(point)

class HeapElement:
	def __init__(self,value,i,j):
		self.error = value
		if i<j:
			self.i = i
			self.j = j
		else:
			self.i = j
			self.j = i

class Heap:
	heapCount = 0
	def __init__(self,pointList):
		self.heap = []
		self.root = None
		self.error = 0
		self.clusters=[1]*len(pointList)
		self.mergedWith = [-1]*len(pointList)
		self.heapArray = [None] * len(pointList)
		self.iteration = 0
		for i in range(0,len(pointList)):
			self.heapArray[i] = [None]* len(pointList)
		self.createHeap(pointList)
		

	def createHeap(self,pointList):
		for i in range(0,len(pointList)):
			for j in range(i+1,len(pointList)):
				self.insertPoint(pointList[i],pointList[j])

	def heapifyUp(self,insertLocation):
		while insertLocation>0:
			if insertLocation % 2 == 0:
				parent = int((insertLocation-2)/2)
			else:
				parent = int((insertLocation-1)/2)
			if self.heap[parent].error > self.heap[insertLocation].error:
				temp = copy.deepcopy(self.heap[parent])
				i = temp.i
				j = temp.j
				self.heap[parent] = copy.deepcopy(self.heap[insertLocation])
				self.heap[insertLocation] = copy.deepcopy(temp)
				self.heapArray[i][j] = insertLocation
				insertLocation = parent
			else:
				break
		return insertLocation

	def heapifyDown(self,i):
		while (2*i+1) < Heap.heapCount:
			if (2*i+2) < Heap.heapCount:
				if self.heap[2*i+1].error < self.heap[2*i+2].error:
					nextElem = 2*i+1
				else:
					nextElem = 2*i+2
				if self.heap[i].error > self.heap[nextElem].error:

					temp = copy.deepcopy(self.heap[i])
					self.heapArray[self.heap[nextElem].i][self.heap[nextElem].j] = i
					self.heapArray[self.heap[i].i][self.heap[i].j] = nextElem
					self.heap[i] = copy.deepcopy(self.heap[nextElem])
					self.heap[nextElem] = copy.deepcopy(temp)
					i = nextElem
				else:
					break
			else:
				nextElem = 2*i+1
				if self.heap[i].error > self.heap[nextElem].error:
					temp = copy.deepcopy(self.heap[i])
					self.heapArray[self.heap[nextElem].i][self.heap[nextElem].j] = i
					self.heapArray[self.heap[i].i][self.heap[i].j] = nextElem
					self.heap[i] = copy.deepcopy(self.heap[nextElem])
					self.heap[nextElem] = copy.deepcopy(temp)
					i = nextElem
				else:
					break

	def insertPoint(self, cluster1, cluster2):
		ni = len(cluster1.pointList)
		nj = len(cluster2.pointList)
		ui = cluster1.point.coordinates
		uj = cluster2.point.coordinates
		errorIncrease = 0
		for i in range(0,len(ui)):
			errorIncrease += (((ni*nj)/(ni+nj))*((ui[i] - uj[i])**2))
		#print ni,nj
		#errorIncrease = errorIncrease**(0.5)
		newElement = HeapElement(errorIncrease,cluster1.count,cluster2.count)
		self.heap.append(newElement)
		insertLocation = Heap.heapCount
		Heap.heapCount += 1		
		self.heapArray[newElement.i][newElement.j] = self.heapifyUp(insertLocation)

	def removeMin(self,pointList):
		minElem = copy.deepcopy(self.heap[0])
		self.error = self.error + minElem.error
		print "Merging clusters with centers",pointList[minElem.i].point.coordinates,"and",pointList[minElem.j].point.coordinates,". The increase in error is",minElem.error,". The total error is",self.error
		self.mergedWith[pointList[minElem.j].count] = pointList[minElem.i].count
		pointList[minElem.i].pointList = copy.deepcopy(pointList[minElem.i].pointList) + copy.deepcopy(pointList[minElem.j].pointList)
		pointList[minElem.j].pointList = copy.deepcopy(pointList[minElem.i].pointList)
		newCenter = []
		ni = len(pointList[minElem.i].pointList)
		nj = len(pointList[minElem.j].pointList)
		ui = pointList[minElem.i].point.coordinates
		uj = pointList[minElem.j].point.coordinates
		for i in range(0,len(ui)):
			newCenter.append(((ni*ui[i])+(nj*uj[i]))/(ni+nj))
		pointList[minElem.i].update(Point(newCenter))
		pointList[minElem.j].update(Point(newCenter))
		print "New cluster center: ",newCenter
		pointPrint = []
		for i in pointList[minElem.i].pointList:
			pointPrint.append(i.coordinates)
		print "New cluster points: ",pointPrint
		print
		print
		self.clusters[minElem.j] = 0
		Heap.heapCount = Heap.heapCount - 1
		self.heap[0] = copy.deepcopy(self.heap[Heap.heapCount])
		self.heapArray[self.heap[Heap.heapCount].i][self.heap[Heap.heapCount].j] = 0
		self.heapifyDown(0)
		self.heapArray[minElem.i][minElem.j] = -1
		for i in range(0,len(pointList)):
			for j in range(i+1,len(pointList)):
				if i==minElem.j or j==minElem.j:
					if self.heapArray[i][j] != -1:
						Heap.heapCount = Heap.heapCount - 1
						self.heap[self.heapArray[i][j]] = copy.deepcopy(self.heap[Heap.heapCount])
						self.heapArray[self.heap[Heap.heapCount].i][self.heap[Heap.heapCount].j] = self.heapArray[i][j]
						self.heapifyDown(self.heapArray[i][j])
						self.heapArray[i][j] = -1
		for i in range(0,len(pointList)):
			for j in range(i+1,len(pointList)):
				if i == minElem.i or j == minElem.i:
					if self.heapArray[i][j] != -1:
						ni = len(pointList[i].pointList)
						nj = len(pointList[j].pointList)
						ui = pointList[i].point.coordinates
						uj = pointList[j].point.coordinates
						errorIncrease = 0
						for q in range(0,len(ui)):
							errorIncrease += (((ni*nj)/(ni+nj))*((ui[q] - uj[q])**2))**2
						errorIncrease = errorIncrease**(0.5)
						if errorIncrease > self.heap[self.heapArray[i][j]].error:
							self.heap[self.heapArray[i][j]].error = errorIncrease
							self.heapifyDown(self.heapArray[i][j])
						else:
							self.heap[self.heapArray[i][j]].error = errorIncrease
							self.heapArray[i][j] = self.heapifyUp(self.heapArray[i][j])

		


	def mergeClusters(self,pointList):
		self.removeMin(pointList)


class Hierarchical:
	def __init__(self,pointList):
		self.pointList = []
		self.root = None
		self.treeList = []
		self.treeHash = []
		self.treeLength = 1
		try:
			self.dim = len(pointList[0])
		except:
			self.dim = 1
		self.error = None
		i = 0
		for point in pointList:
			self.pointList.append(Centroid(Point(point)))
			self.treeList.append(Node(point))
			self.treeHash.append(i)
			i += 1
		self.heapArray = Heap(self.pointList)
		mergeArray = [1]*len(pointList)
		iteration = 1
		while self.heapArray.heapCount > 0:
			if self.heapArray.heapCount >0:
				print "Iteration",iteration,": ",
			else:
				print "Iteration",iteration,": ","Done"
			self.heapArray.mergeClusters(self.pointList)
			
			iteration += 1
			# for elem in self.heapArray.heapArray:
			# 	print elem
			for i in range(0,len(pointList)):
				if self.heapArray.clusters[i]!=1:
					if(mergeArray[i] == 1):
						mergeArray[i] = 0
						c = []
						for elem in self.pointList[i].pointList:
							c.append(elem.coordinates)					
						#print c
						node = Node(self.pointList[i].point.coordinates)
						node.left = self.treeList[self.treeHash[self.heapArray.mergedWith[i]]]
						node.right = self.treeList[self.treeHash[i]]
						self.treeList[self.treeHash[self.heapArray.mergedWith[i]]].parent = node
						self.treeList[self.treeHash[i]].parent = node
						node.pointList = c
						self.treeList.append(node)
						self.treeHash[self.heapArray.mergedWith[i]] = len(self.treeList) - 1
						self.treeLength += 1
						#print i,self.pointList[i].point.coordinates,self.heapArray.mergedWith[i]
		self.root = self.treeList[len(self.treeList) - 1]
		

	def printTree(self):
		print ""
		print "Final tree (Showing Cluster Centers)"
		print
		toPrint = []
		toPrint.append(self.root)
		tabs = self.treeLength
		strlen = 1
		while len(toPrint) > 0:
			printString = ""
			printString += "   "*tabs
			nextArr = list()
			k = 0
			for i in toPrint:
				if k!=0 and k%2==0:
					printString += str(i.coordinates)+"\t"
				else:
					printString += str(i.coordinates)+" "
				k += 1
				if len(str(i.coordinates)) > strlen:
					strlen = len(str(i.coordinates))
				if i.left != None:
					nextArr.append(i.left)
				if i.right != None:
					nextArr.append(i.right)
			print printString+"\n"
			tabs -= 1	
			toPrint = copy.deepcopy(nextArr)
		#self.mainFunc():

	def printTree1(self):
		print ""
		print "Final (Showing Cluster Centers)"
		print
		print "Iteration 0:",
		for i in range(0,len(self.pointList)):
			print self.treeList[i].coordinates," ",
		print
		print
		it = 1
		for i in range(len(self.pointList), len(self.treeList)):
			print "Iteration",it,":", self.treeList[i].left.coordinates,"+",self.treeList[i].right.coordinates,"-->",self.treeList[i].coordinates
			print
			it += 1
		print

		print ""
		print "Final (Showing Cluster Points)"
		print
		print "Iteration 0:",
		for i in range(0,len(self.pointList)):
			print self.treeList[i].pointList," ",
		print
		print
		it = 1
		for i in range(len(self.pointList), len(self.treeList)):
			print "Iteration",it,":", self.treeList[i].left.pointList,"+",self.treeList[i].right.pointList,"-->",self.treeList[i].pointList
			print
			it += 1
		print

fileName = sys.argv[1]
with open(fileName,"r") as inputFile:
	content = inputFile.readlines()
pointList = []
for line in content:
	c = line.split(",")
	point = list()
	for i in c:
		point.append(float(i))
	pointList.append(point)
print ""
print "Starting with cluster centers: ",pointList
print 
print
#print pointList
start_time = time.time()
a = Hierarchical(pointList)
end_time = time.time()
a.printTree1()
print("Total Time: %s seconds" % (time.time() - end_time))